package elevatorProject;

public enum Direction {
	 UP,
	 DOWN,
	 IDLE
}
